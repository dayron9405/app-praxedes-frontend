
export interface UserInterface {

  nombre: string;
  apellido: string;
  doctoIdent: string;
  email: string;
  clave: string;
  cia: string;

}
