export interface PersonageInterface {

  id_caracter: number;
  name: string;
  species: string;
  image: string

}
