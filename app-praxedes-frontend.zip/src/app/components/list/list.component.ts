import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class ListComponent implements OnInit {

  @Input() options: any[] = [];

  @Output() selectOptionEmiter: EventEmitter<any>;

  constructor() {
    this. selectOptionEmiter = new EventEmitter();
  }

  ngOnInit(): void {
  }

  selectedOption(option){
    this.selectOptionEmiter.emit(option);
  }

}
