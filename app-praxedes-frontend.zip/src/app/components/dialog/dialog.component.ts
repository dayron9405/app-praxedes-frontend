import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { PersonageInterface } from 'src/app/models/personage/personage-interface';
import { FavoriteService } from 'src/app/services/favorite-service/favorite.service';

@Component({
  selector: 'app-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.scss']
})
export class DialogComponent implements OnInit {

  typesOfShoes: string[] = ['Boots', 'Clogs', 'Loafers', 'Moccasins', 'Sneakers'];
  data: any[] = []
  episodio: string = '';

  constructor(
    @Inject(MAT_DIALOG_DATA) public dataDialog: any[],
    private favoriteService: FavoriteService,
    public dialogRef: MatDialogRef<any>
  ) { }

  ngOnInit(): void {
    this.data = this.dataDialog['personages'];
    this.episodio = this.dataDialog['episodio'];
  }

  selectedOption(option: PersonageInterface){
    const name = `${option.name}`;
    const image = `${option.image}`;
    const species = `${option.species}`;
    delete option.name;
    delete option.image;
    delete option.species;
    this.favoriteService.createFavorite(option).subscribe(res => {
      console.log('res create favorite', res)
    }, (err) => {
      console.log('Error: ', err)
    })
    option.name = name;
    option.image = image;
    option.species = species;
  }

}
