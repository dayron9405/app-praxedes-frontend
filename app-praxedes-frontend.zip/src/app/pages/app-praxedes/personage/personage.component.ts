import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { PersonageInterface } from 'src/app/models/personage/personage-interface';

// services
import { PersonageService } from 'src/app/services/personage-service/personage.service';

@Component({
  selector: 'app-personage',
  templateUrl: './personage.component.html',
  styleUrls: ['./personage.component.scss']
})
export class PersonageComponent implements OnInit {

  titleModule: string = 'PERSONAJES';
  listPersonages: PersonageInterface[] = [];
  count: number = 0;
  pagesSize: number = 0;
  optionsRange: number = 20;
  page: number = 1;

  constructor(
    private personageServise: PersonageService,
    public dialog: MatDialog
  ) { }

  ngOnInit(): void {
    this.getListPersonages(this.page);
  }

  getListPersonages(pageSelect){
    this.personageServise.listPersonages(pageSelect).subscribe(res => {
      this.count = res.info.count;
      this.pagesSize = res.info.pages;
      this.optionsRange = res.results.length;
      const dataPersonages = res.results.map(element => {
        return {
          id_caracter: element.id,
          name: element.name,
          species: element.species,
          image: element.image
        }
      });
      this.listPersonages = dataPersonages;
    })
  }

  changePage(event){
    this.page = (event.pageIndex+1);
    this.getListPersonages(this.page);
  }

  selectedOption(option){
    console.log('Personage option', option)
  }

}
