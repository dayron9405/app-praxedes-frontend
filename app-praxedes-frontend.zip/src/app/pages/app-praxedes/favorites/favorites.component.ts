import { Component, OnInit } from '@angular/core';

// Services
import { FavoriteService } from 'src/app/services/favorite-service/favorite.service';

@Component({
  selector: 'app-favorites',
  templateUrl: './favorites.component.html',
  styleUrls: ['./favorites.component.scss']
})
export class FavoritesComponent implements OnInit {

  titleModule: string = 'FAVORITOS';
  listFavorites: any[] = [];
  count: number = 0;
  pagesSize: number = 0;
  optionsRange: number = 20;
  page: number = 1;

  constructor(
    private favoriteService: FavoriteService
  ) {}

  ngOnInit(): void {
    this.getListFavorites(this.page);
  }

  getListFavorites(pageSelect){
    this.favoriteService.listFavorite(pageSelect).subscribe(res => {
      console.log('res favorite', res)
    })
  }

  changePage(event){
    this.page = (event.pageIndex+1);
    this.getListFavorites(this.page);
  }

  selectedOption(option){
    console.log('Personage option', option)
  }

}
