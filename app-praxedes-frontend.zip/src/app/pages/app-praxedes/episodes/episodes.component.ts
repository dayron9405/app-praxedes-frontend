import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';

//components
import { DialogComponent } from 'src/app/components/dialog/dialog.component';

// Services
import { EpisodesService } from 'src/app/services/episodes-service/episodes.service';
import { PersonageService } from 'src/app/services/personage-service/personage.service';

@Component({
  selector: 'app-episodes',
  templateUrl: './episodes.component.html',
  styleUrls: ['./episodes.component.scss']
})
export class EpisodesComponent implements OnInit {

  titleModule: string = 'EPISODIOS';
  listEpisodes: any[] = [];
  count: number = 0;
  pagesSize: number = 0;
  optionsRange: number = 20;
  page: number = 1;


  constructor(
    private episodeService: EpisodesService,
    private personageService: PersonageService,
    public dialog: MatDialog
  ) { }

  ngOnInit(): void {
    this.getListEpisodes(this.page);
  }

  getListEpisodes(pageSelect){
    this.episodeService.listEpisodes(pageSelect).subscribe((res) => {
      this.count = res.info.count;
      this.pagesSize = res.info.pages;
      this.optionsRange = res.results.length;
      this.listEpisodes = res.results;
    }, (err) => {
      console.log('err: ', err)
    })
  }

  changePage(event){
    this.page = (event.pageIndex+1);
    this.getListEpisodes(this.page);
  }

  openDialog(event) {
    const { characters, name } = event;
    const personages = [];
    characters.map(element => {
      const id = element.split('character/').pop();
      this.personageService.personage(id).subscribe(res => {
        personages.push({
          id_caracter: res.id,
          name: res.name,
          species: res.species,
          image: res.image
        })
      })
    })
    const dialogRef = this.dialog.open(DialogComponent, {
      data: {
        personages: personages,
        episodio: name
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }

}
